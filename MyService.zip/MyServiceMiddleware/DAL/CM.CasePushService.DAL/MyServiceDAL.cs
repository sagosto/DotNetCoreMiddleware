﻿using CM.MyService.Common.Models.Interfaces;
using CM.MyService.DAL.Contracts;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

namespace CM.MyService.DAL
{
    /// <summary>
    /// MyService's Data Access Layer
    /// </summary>
    public class MyServiceDAL : IMyServiceDAL
    {
        #region Variables

        private readonly RequestDelegate _next;
        private IGetResponse _iGetResponse = null;

        #endregion Variables

        #region Constructors
        
        public MyServiceDAL(RequestDelegate next)
        {
            System.Diagnostics.Debug.WriteLine("MyServiceDAL constructor");
            this._next = next;
        }

        public Task Invoke(HttpContext httpContext, IGetResponse iGetResponse)
        {
            System.Diagnostics.Debug.WriteLine("Invoke constructor");
            this._iGetResponse = iGetResponse;
            return this._next(httpContext);
        }
        
        #endregion Constructors

        #region Methods

        public async Task<IGetResponse> GetAsync()
        {
            // Counter incremented each request
            this._iGetResponse.counter++;
            System.Diagnostics.Debug.WriteLine($"GetAsync: { this._iGetResponse.counter }");
            return this._iGetResponse;
        }

        #endregion Methods
    }
}