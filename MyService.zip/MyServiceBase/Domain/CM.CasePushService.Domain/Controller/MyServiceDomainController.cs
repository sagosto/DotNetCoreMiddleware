﻿using CM.MyService.Common.Models.Interfaces;
using CM.MyService.DAL.Contracts;
using CM.MyService.Domain.Contracts;
using System.Threading.Tasks;

namespace CM.MyService.Domain.Controller
{
    /// <summary>
    /// MyService Domain Controller
    /// </summary>
    public class MyServiceDomainController : IMyServiceDomainController
    {
        #region Variables

        private readonly IMyServiceDAL _iMyServiceDAL = null;
        private IGetResponse _iGetResponse = null;
            
        #endregion Variables

        #region Constructors
        
        public MyServiceDomainController(IMyServiceDAL iMyServiceDAL, IGetResponse iGetResponse)
        {
            System.Diagnostics.Debug.WriteLine("MyServiceDomainController constructor");
            this._iMyServiceDAL = iMyServiceDAL;
            this._iGetResponse = iGetResponse;
        }

        #endregion Constructors

        #region Methods      

        public async Task<IGetResponse> GetAsync()
        {
            this._iGetResponse = await _iMyServiceDAL.GetAsync();
            return this._iGetResponse;
        }

        #endregion Methods
    }
}