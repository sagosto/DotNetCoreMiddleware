﻿using CM.MyService.Common.Models.Interfaces;
using System.Threading.Tasks;

namespace CM.MyService.Domain.Contracts
{
    /// <summary>
    /// MyService's Domain controller contract's interface
    /// </summary>
    public interface IMyServiceDomainController
    {        
        Task<IGetResponse> GetAsync();
    }
}