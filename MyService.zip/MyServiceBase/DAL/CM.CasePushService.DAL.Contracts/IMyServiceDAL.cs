﻿using CM.MyService.Common.Models.Interfaces;
using System.Threading.Tasks;

namespace CM.MyService.DAL.Contracts
{
    /// <summary>
    /// MyService's Data Access Layer's contracts' interfaces
    /// </summary>
    public interface IMyServiceDAL
    {
        Task<IGetResponse> GetAsync();      
    }
}