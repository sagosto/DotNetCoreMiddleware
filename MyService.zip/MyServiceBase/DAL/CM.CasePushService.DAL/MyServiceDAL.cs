﻿using CM.MyService.Common.Models.Interfaces;
using CM.MyService.DAL.Contracts;
using System.Threading.Tasks;


namespace CM.MyService.DAL
{
    /// <summary>
    /// MyService's Data Access Layer
    /// </summary>
    public class MyServiceDAL : IMyServiceDAL
    {
        #region Variables

        //private readonly RequestDelegate _next;
        private IGetResponse _iGetResponse = null;

        #endregion Variables

        #region Constructors
        
        public MyServiceDAL(IGetResponse iGetResponse)
        {
            System.Diagnostics.Debug.WriteLine("MyServiceDAL constructor");
            this._iGetResponse = iGetResponse;
        }

        //public MyServiceDAL(RequestDelegate next)
        //{
        //    this._next = next;
        //}

        //public Task Invoke(HttpContext httpContext, IGetResponse iGetResponse)
        //{
        //    this._iGetResponse = iGetResponse;
        //    return this._next(httpContext);
        //}
        

        #endregion Constructors

        #region Methods

        public async Task<IGetResponse> GetAsync()
        {
            // Counter incremented each request
            this._iGetResponse.counter++;
            System.Diagnostics.Debug.WriteLine($"GetAsync: { this._iGetResponse.counter }");
            return this._iGetResponse;
        }

        //public class MyDAL
        //{
        //    private readonly RequestDelegate _next;
        //    private IGetResponse _iGetResponse = null;

        //    public MyDAL(RequestDelegate next)
        //    {
        //        this._next = next;
        //    }
        //    // IMyScopedService is injected into Invoke
        //    public Task Invoke(HttpContext httpContext, IGetResponse iMyResponse)
        //    {
        //        this._iGetResponse = iMyResponse;
        //        return this._next(httpContext);
        //    }
        // }
        #endregion Methods
    }
}