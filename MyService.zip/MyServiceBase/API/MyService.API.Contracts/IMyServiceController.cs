﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace CM.MyService.API.Contracts
{
    public interface IMyServiceController
    {
        Task<IActionResult> Get();
    }
}