﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Steeltoe.Extensions.Configuration.ConfigServer;
using Swashbuckle.AspNetCore.Swagger;
using CM.MyService.Common.DIFramework;

namespace CM.MyService.API
{
    /// <summary>
    /// Startup class
    /// </summary>
    public class Startup
    {
        #region Properties
        
        /// <summary>
        /// Configuration 
        /// </summary>
        public IConfiguration Configuration { get; }

        #endregion Properties

        #region Constructors

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="iConfiguration">Configuration interface</param>
        public Startup(IConfiguration iConfiguration)
        {
            this.Configuration = iConfiguration;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Configure services
        /// </summary>
        /// <param name="services">Services</param>
        /// <remarks>This method gets called by the runtime. Use this method to add services to the container.</remarks>
        public void ConfigureServices(IServiceCollection services)
        {
            // Add memory cache
            services.AddMemoryCache();

            services.AddMvc();

            services.AddCors(o => o.AddPolicy("corspolicy",
                builder => builder.AllowAnyOrigin()
                .AllowAnyHeader()
                .AllowAnyMethod()));

            services.AddSingleton(this.Configuration);

            // Application-Wide Services
            services.AddApplicationServices();

			// Configuration
            services.AddOptions();
            services.ConfigureConfigServerClientOptions(this.Configuration);
            services.AddConfiguration(this.Configuration);
           
            // Configure Swagger
            services.AddSwaggerGen(s =>
            {
                s.SwaggerDoc("v1",
                new Info
                {
                    Title = "API",
                    Version = "v1",
                    Description = "This API supports functionality related to... ",
                });
            });
        }

        /// <summary>
        /// Configure the application
        /// </summary>
        /// <param name="iApplicationBuilder">Application Builder interface</param>
        /// <param name="iHostingEnvironment">Hosting Environment interface</param>
        /// <param name="iMemoryCache">Memory Cache interface</param>
        /// <param name="iApplicationLifetime">Application Lifetime interface</param>
        /// <remarks>This method gets called by the runtime. Use this method to configure the HTTP request pipeline.</remarks>
        public void Configure(IApplicationBuilder iApplicationBuilder, IHostingEnvironment iHostingEnvironment, IMemoryCache iMemoryCache, IApplicationLifetime iApplicationLifetime)
        {
            if (iHostingEnvironment.IsDevelopment() == true)
            {
                iApplicationBuilder.UseDeveloperExceptionPage();
                iApplicationBuilder.UseStatusCodePages();

                iApplicationBuilder.UseDatabaseErrorPage();
                iApplicationBuilder.UseBrowserLink();
            }

            if (iHostingEnvironment.IsProduction() == false)
            {
                // Enable Swagger for API documentation
                iApplicationBuilder.UseSwagger();
                iApplicationBuilder.UseSwaggerUI(s =>
                {
                    s.SwaggerEndpoint("./v1/swagger.json", "API");
                });
            }

            // Use UseMyServiceDAL's middleware
            //iApplicationBuilder.UseMyServiceDALMiddleware();

            iApplicationBuilder.UseMvc();

            // Application Events
            iApplicationLifetime.ApplicationStarted.Register(this.OnApplicationStarted);
            iApplicationLifetime.ApplicationStopped.Register(this.OnApplicationStopping);
        }
        
        #endregion Methods

        #region Events

        /// <summary>
        /// Handles the Application's Started event
        /// </summary>
        public void OnApplicationStarted()
        {
            // Do nothing
        }

        /// <summary>
        /// Handles the Application's Stopping event
        /// </summary>
        public void OnApplicationStopping()
        {
            // Do nothing
        }

        #endregion Events
    }

    ///// <summary>
    ///// Middleware Extensions
    ///// </summary>
    //public static class MiddlewareExtensions
    //{
    //    /// <summary>
    //    /// Use middleware
    //    /// </summary>
    //    /// <param name="builder">App Builder</param>
    //    /// <returns>IApplicationBuilder</returns>
    //    public static IApplicationBuilder UseMyServiceDALLMiddleware(this IApplicationBuilder builder)
    //    {
    //        return builder.UseMiddleware<DAL.MyServiceDAL>();
    //    }
    //}
}