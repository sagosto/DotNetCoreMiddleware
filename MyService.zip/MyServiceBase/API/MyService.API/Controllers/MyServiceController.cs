﻿using CM.MyService.API.Contracts;
using CM.MyService.Common.Models.Interfaces;
using CM.MyService.Domain.Contracts;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace CM.MyService.API
{
    /// <summary>
    /// MyService Controller class
    /// </summary>
    [Route("api/[controller]")]
    [EnableCors("corspolicy")]
    public class MyServiceController : Controller, IMyServiceController
    {
        private readonly IMyServiceDomainController _iMyServiceDomainController = null;
        private IGetResponse _iGetResponse = null;

        public MyServiceController(IMyServiceDomainController iMyServiceDomainController, IGetResponse iGetResponse)
        {
            System.Diagnostics.Debug.WriteLine("MyServiceController constructor");
            this._iMyServiceDomainController = iMyServiceDomainController;
            this._iGetResponse = iGetResponse;
        }
    
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            // Get
            this._iGetResponse = await this._iMyServiceDomainController.GetAsync();
            if (this._iGetResponse != null) { return Ok(this._iGetResponse); } else { return (IActionResult)NotFound(this._iGetResponse); }
        }
    }
}