﻿using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Logging;
using NLog.Web;
using Steeltoe.Extensions.Configuration.ConfigServer;
using System;

namespace CM.MyService.API
{
    /// <summary>
    /// Program
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Main
        /// </summary>
        /// <param name="args">Arguments</param>
        public static void Main(string[] args)
        {
            try
            {
                Program.BuildWebHost(args).Run();
            }
            catch (Exception)
            {
                throw;
            }            
        }

        /// <summary>
        /// Build WebHost
        /// </summary>
        /// <param name="args">Arguments</param>
        /// <returns>WebHost interface</returns>
        public static IWebHost BuildWebHost(string[] args)
        {
            try
            {
                var config = WebHost.CreateDefaultBuilder(args)
                            .CaptureStartupErrors(true)
                            .AddConfigServer()
                            .UseStartup<Startup>()
                            .ConfigureLogging(logging =>
                            {
                                logging.ClearProviders();
                                logging.SetMinimumLevel(LogLevel.Trace);
                            })
                            .UseNLog()  // NLog: setup NLog for Dependency injection
                            .Build();

                return config;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}