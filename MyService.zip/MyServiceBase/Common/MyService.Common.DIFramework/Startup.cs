﻿using CM.MyService.Common.Models.Interfaces;
using CM.MyService.Common.Models.Responses;
using CM.MyService.DAL;
using CM.MyService.DAL.Contracts;
using CM.MyService.Domain.Contracts;
using CM.MyService.Domain.Controller;
using Microsoft.Extensions.DependencyInjection;

namespace CM.MyService.Common.DIFramework
{
    /// <summary>
    /// Startup
    /// </summary>
    public static class Startup
    {
        #region Methods

        /// <summary>
        /// Add application services
        /// </summary>
        /// <param name="services">Services</param>
        /// <returns>Services</returns>
        public static IServiceCollection AddApplicationServices(this IServiceCollection services)
        {
            if (services == null) { return services; }

            services.AddSingleton<IMyServiceDomainController, MyServiceDomainController>();
            services.AddSingleton<IMyServiceDAL, MyServiceDAL>();
            services.AddTransient<IGetResponse, GetResponse>();

            return services;
        }

        #endregion Methods
    }
}