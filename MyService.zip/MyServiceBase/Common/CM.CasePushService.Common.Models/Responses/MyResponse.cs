﻿using CM.MyService.Common.Models.Interfaces;

namespace CM.MyService.Common.Models.Responses
{
    /// <summary>
    /// Get Request class
    /// </summary>
    public class GetResponse : IGetResponse
    {
        public int counter { get; set; }
    }
}