﻿namespace CM.MyService.Common.Models.Interfaces
{
    /// <summary>
    /// Get Response's interface
    /// </summary>
    public interface IGetResponse
    {
        #region Properties

        int counter { get; set; }

        #endregion Properties
    }
}